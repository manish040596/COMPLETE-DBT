SELECT

    TRIM(product_id)                       AS product_id,

    TRIM(product_name)                     AS product_name,

    UPPER(TRIM(category))                  AS category,

    INITCAP(TRIM(brand))                   AS brand,

    TRY_TO_NUMBER(price,10,2)              AS price

FROM {{ source('retail_raw','RAW_PRODUCTS') }}
WHERE product_id <> 'ProductID'