SELECT

    TRY_TO_NUMBER(order_id)          AS order_id,

    TRIM(product_id)                 AS product_id,

    TRY_TO_NUMBER(quantity)          AS quantity

FROM {{ source('retail_raw','RAW_ORDER_ITEMS') }}
where TRY_TO_NUMBER(order_id)  is not null