SELECT

    TRY_TO_NUMBER(order_id)          AS order_id,

    TRY_TO_NUMBER(customer_id)       AS customer_id,

    TRY_TO_DATE(order_date)          AS order_date,

    UPPER(TRIM(order_status))        AS order_status

FROM {{ source('retail_raw','RAW_ORDERS') }}

where TRY_TO_NUMBER(order_id)  is not null