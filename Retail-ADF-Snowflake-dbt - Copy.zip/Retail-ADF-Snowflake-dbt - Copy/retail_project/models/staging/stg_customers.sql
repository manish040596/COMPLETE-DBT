SELECT

    TRY_TO_NUMBER(customer_id)         AS customer_id,

    TRIM(customer_name)                AS customer_name,

    LOWER(TRIM(email))                 AS email,

    INITCAP(TRIM(city))                AS city,

    UPPER(TRIM(state))                 AS state,

    TRIM(phone)                        AS phone,

    TRY_TO_DATE(created_date)          AS created_date

FROM {{ source('retail_raw','RAW_CUSTOMERS') }}

where TRY_TO_NUMBER(customer_id)  is not null