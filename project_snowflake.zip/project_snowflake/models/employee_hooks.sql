
{{ config(
    materialized='table',

    pre_hook="truncate table employee_hooks",

    post_hook="
        INSERT INTO AUDIT_LOG
        VALUES(
            CURRENT_TIMESTAMP(),
            'EMPLOYEE_MODEL',
            'SUCCESS'
        )
    "
) }}

select * from emp_test1