-- select {{'Hello'}}

-- {% set salary=10000 %}
-- {% set country='india' %}
-- {% set discount=200 %}
-- select {{salary}},'{{country}}',{{salary-discount}}


-- if else 

-- salary = 10000

-- if salary>25000:
--    print('high salary')
-- else:
--    print('lowest salary')

-- jinja sql 

-- {%set salary = 10000%}
-- {%if salary>25000%}
-- select 'High salary'
-- {%else%}
-- select 'Low salary'
-- {%endif%}


--for loop -- Jinja sql 

-- columns = ['id','name','salary','country']

-- for col in columns:
--    print(col)

-- {%set columns = ['id','name','salary','country']%}
-- select
-- {%for col in columns%}
-- {{col}}
-- {%if not loop.last%}
-- ,
-- {%endif%}
-- {%endfor%}
-- from table


-- DBT INBUILT OBJECT 

-- 1. TARGET

SELECT '{{target.database}}','{{target.schema}}','{{target.name}}'

--2 . this 

select '{{this}}'



-- var()

-- {%set country = 'india'%}

SELECT 
{{var('country')}} as country,
{{var('department')}} as department,
{{var('salary')}} as salary
from table


{{hello_world()}}