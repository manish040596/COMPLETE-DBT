
{{ config(materialized='incremental',unique_key='EMP_ID') }}
select * from employee_incremental

{% if is_incremental() %}

where updated_at >

(
select max(updated_at)

from {{ this }} 


)

{% endif %}