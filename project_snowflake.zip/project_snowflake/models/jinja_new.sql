select '{{this}}'

SELECT 
{{var('country')}} as country,
{{var('department')}} as department,
{{var('salary')}} as salary,
{{audit_columns()}}
from table


{{hello_world()}}