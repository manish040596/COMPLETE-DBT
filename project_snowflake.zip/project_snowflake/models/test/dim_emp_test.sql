

select id , lower(name) as name , salary , case when country='IND' then 'india' else lower(country) end as country,
{{audit_columns()}},{{ dbt_utils.generate_surrogate_key(['id','name']) }}
from  {{ source('raw','emp_test1') }}


