{{ config(alias='emp_new_info',tags=['finance']) }}

select * from {{ ref('dim_emp_test') }}


--tags 