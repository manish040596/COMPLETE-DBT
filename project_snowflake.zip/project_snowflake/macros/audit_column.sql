{%macro audit_columns()%}
current_timestamp() as load_time,
'manish' as user
{%endmacro%}