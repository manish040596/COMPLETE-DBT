{%macro hello_world()%}
'hello world'
{% endmacro %}