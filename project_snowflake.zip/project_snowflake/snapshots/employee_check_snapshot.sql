{% snapshot employee_check_snapshot %}

{{
config(
    target_schema='SNAPSHOT',
    unique_key='EMP_ID',
    strategy='check',
    check_cols=['DEPARTMENT','SALARY']
)
}}

select *
from EMPLOYEE_CHECK

{% endsnapshot %}