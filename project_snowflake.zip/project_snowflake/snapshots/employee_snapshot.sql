{% snapshot employee_snapshot %}

{{
config(

target_schema='SNAPSHOT',

unique_key='EMP_ID',

strategy='timestamp',

updated_at='UPDATED_AT'

)

}}

select *

from emp_test2

{% endsnapshot %}